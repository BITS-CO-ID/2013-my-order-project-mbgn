 $(document).ready(function() {
    $('#showcart').click(function() {
            $('.cart-hover').toggle("slide");
    });
});